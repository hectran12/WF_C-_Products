namespace two_dimensional_array_button
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Button[,] arBtn = null;
        Random rd = new Random();
        Button last = null;
        private void btn_spambutton_Click(object sender, EventArgs e)
        {
            int dong = Convert.ToInt32(txt_dong.Text);
            int cot = Convert.ToInt32(txt_cot.Text);
            arBtn = new Button[dong, cot];  
            panel2.Controls.Clear();
            for (int i=0; i<arBtn.GetLength(0); i++)
            {
                for (int j=0; j<arBtn.GetLength(1); j++)
                {
                    Button btn = new Button();
                    int num = rd.Next(102);
                    btn.Text = num + "";
                    btn.Width = btn.Height = 50;
                    btn.Location = new Point(i*btn.Width, j*btn.Height);
                    btn.Tag = i + ";" + j;
                    btn.BackColor = Color.WhiteSmoke;
                    btn.Click += action_click;
                    panel2.Controls.Add(btn);
                    arBtn[i, j] = btn;
                }
            }
        }


        private void change_color (Control button , Color mau)
        {
            string tags = button.Tag.ToString();
            string[] iz = tags.Split(';');
            int i = Convert.ToInt32(iz[0]);
            int j = Convert.ToInt32(iz[1]);
            for (int c = 0; c < arBtn.GetLength(1); c++)
            {
                arBtn[i, c].BackColor = mau;
            }
            for (int d = 0; d< arBtn.GetLength(0); d++)
            {
                arBtn[d, j].BackColor = mau;
            }
        }
        private void action_click(object? sender, EventArgs e)
        {
            if(last != null)
            {
                change_color(last,Color.WhiteSmoke);
            }
            Button btn = sender as Button;
            last = btn;
            
            change_color(last, Color.Green);
            last.BackColor = Color.Blue;
        }
    }
}