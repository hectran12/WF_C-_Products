namespace RuntimeButton_Test
{
    public partial class runtime : Form
    {
        Button last = null;
        public runtime()
        {
            InitializeComponent();
        }

        private void runtime_Load(object sender, EventArgs e)
        {
            panel1.BackColor = SystemColors.GrayText;
           
        }

        private void btn_add_button_Click(object sender, EventArgs e)
        {
            Button btn = new Button();
            Random rd = new Random();
            btn.Text = rd.Next(102) + "";
            btn.Height = 100;
            btn.Width = 100;
            btn.Click += btn_click_action;
            int num = panel1.Height;
            btn.Location = new Point(rd.Next(num), rd.Next(num));
            panel1.Controls.Add(btn);
        }

        private void btn_click_action(object? sender, EventArgs e)
        {
            if(last != null)
            {
                last.BackColor = SystemColors.GrayText;
            }
            Button btn = sender as Button;
            btn.BackColor = SystemColors.Highlight;
            last = btn;

        }
    }
}